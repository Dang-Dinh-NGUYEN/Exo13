public class ConcatLight extends Concat{
    public ConcatLight(Expreg exp1, Expreg exp2) {
        super(exp1, exp2);
    }

    public String toString(){
        return "(" + super.toString() + ")";
    }
}
