public class Main {

    public static void main(String[] args) {
        /*
        Epsilon e = new Epsilon() ;
        Symbole a = new Symbole('a') ;
        System.out.println(e.toString ()) ; // affiche : &
        System.out.println(a.toString ()) ; // affiche : a
*/

        //Etoile star = new Etoile ( a ) ;
        //Etoile star2 = new Etoile ( star ) ;
        //System . out . println ( star . toString () ) ; // affiche : ( a ) *
        //System . out . println ( star2 . toString () ) ; // affiche : (( a ) *) *




        Symbole a = new Symbole ('a') ;
        ConcatLight c = new ConcatLight (a , new Somme (a ,new ConcatLight (a , a ) ) ) ;
        System . out . println ( c . toString () ) ; // affiche : ( a .( a + aa ) )

        Epsilon e =  ChaineFactory.creeChaine(" ");
        Symbole s = ChaineFactory.creeChaine("s" );
        Concat abcd = ChaineFactory.creeChaine("abcd" );
        System.out.println(abcd.toString()); // affiche : ( a .( b .( c . d ) ) )


    }
}
