public class Concat extends ExpregBinaire{
    public Concat(Expreg exp1,Expreg exp2){
        super(exp1,".",exp2);
    }
}
