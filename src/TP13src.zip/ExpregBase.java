public interface ExpregBase extends Expreg{// classe racine des expr . de base
}
