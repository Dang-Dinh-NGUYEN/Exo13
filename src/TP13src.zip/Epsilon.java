public class Epsilon extends ChaineFactory implements ExpregBase {

    @Override
    public String toString() {
        return "&";
    }
}
