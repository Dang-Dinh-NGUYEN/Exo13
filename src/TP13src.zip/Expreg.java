public interface Expreg { // classe racine de toutes les expressions regulieres
    String toString () ;  // retourne la chaine de caracteres representant l ’ expression reguliere
}
